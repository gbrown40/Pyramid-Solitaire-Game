package cs3500.pyramidsolitaire;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireController;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;

/**
 * a class representing the playing of the game PyramidSolitaire from the command line.
 */
public class PyramidSolitaire {

  private static PyramidSolitaireController cont;

  static boolean isNumeric(String strNum) {
    try {
      int d = Integer.parseInt(strNum);
    } catch (NumberFormatException | NullPointerException e) {
      return false;
    }
    return true;
  }

  /**
   * the main method, responsible for running gameplay of the Pyramid Solitaire game.
   *
   * @param args represents the arguments passed into the method as an Array of String.
   */
  public static void main(String[] args) {
    ArrayList<String> arrayArg = new ArrayList<>(Arrays.asList(args));
    String board = arrayArg.get(0);
    StringReader in = new StringReader(board);
    StringBuilder out = new StringBuilder();
    cont = new PyramidSolitaireTextualController(in, out);


    if (arrayArg.size() > 2) {
      //checks values right after board type to see if they are numeric,
      //otherwise use default values
      if (isNumeric(arrayArg.get(1)) && isNumeric(arrayArg.get(2))) {
        int row = Integer.parseInt(arrayArg.get(1));
        int draw = Integer.parseInt(arrayArg.get(2));

        PyramidSolitaire.playGame(board, row, draw);
      } else { //uses default values if row number and draw number are not both specified
        PyramidSolitaire.playGame(board, 7, 3);
      }
    } else {
      PyramidSolitaire.playGame(board, 7, 3);
    }


  }


  private static void playGame(String board, int row, int draw) {
    switch (board) {
      case "basic":
        BasicPyramidSolitaire game = new BasicPyramidSolitaire();
        cont.playGame(game, game.getDeck(), true, row, draw);
        break;
      case "relaxed":
        RelaxedPyramidSolitaire game2 = new RelaxedPyramidSolitaire();
        cont.playGame(game2, game2.getDeck(), true, row, draw);
        break;
      case "tripeaks":
        TriPeaksPyramidSolitaire game3 = new TriPeaksPyramidSolitaire();
        cont.playGame(game3, game3.getDeck(), true, row, draw);
        break;
      default:
        // doesn't do anything if the board does not match one of the 3 different board types
    }

  }
}
