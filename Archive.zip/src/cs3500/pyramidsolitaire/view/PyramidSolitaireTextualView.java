package cs3500.pyramidsolitaire.view;

import java.io.IOException;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;


/**
 * Class for the view portion of the game.
 *
 */
public class PyramidSolitaireTextualView implements PyramidSolitaireView {
  private final PyramidSolitaireModel<?> model;
  private Appendable ap;
  // ... any other fields you need

  /**
   * Constructs a PyramidSolitaireTextualView from a given model.
   */
  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model) {

    this.model = model;
  }

  /**
   * Constructs a PyramidSolitaireTextualView from a given model and Appendable.
   */
  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model, Appendable ap) {

    this.model = model;
    this.ap = ap;
  }


  @Override
  public String toString() {
    return this.model.toString();
  }


  @Override
  public void render() throws IOException {
    this.ap.append(this.model.toString() + "\n");

  }
}
