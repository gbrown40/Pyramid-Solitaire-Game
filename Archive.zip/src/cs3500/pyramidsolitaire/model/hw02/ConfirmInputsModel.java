package cs3500.pyramidsolitaire.model.hw02;

import java.util.List;
import java.util.Objects;


/**
 * Mock model to help with testing.
 *
 */
public class ConfirmInputsModel implements PyramidSolitaireModel<Card> {

  final StringBuilder log;

  public ConfirmInputsModel(StringBuilder log) {
    this.log = Objects.requireNonNull(log);
  }

  @Override
  public List<Card> getDeck() {
    return null;
  }

  @Override
  public void startGame(List deck, boolean shouldShuffle, int numRows, int numDraw) {
    log.append(String.format("deck = %d, shouldShuffle = %d, numRows = %d, " +
            "numDraw = %d\n", deck, shouldShuffle, numRows, numDraw));

  }

  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    log.append(String.format("row1 = %d, card1 = %d, row2 = %d, " +
            "card2 = %d\n", row1, card1, row2, card2));

  }

  @Override
  public void remove(int row, int card) throws IllegalStateException {
    log.append(String.format("num1 = %d, num2 = %d\n", row, card));

  }

  @Override
  public void removeUsingDraw(int drawIndex, int row, int card) throws IllegalStateException {
    log.append(String.format("drawIndex = %d, row = %d, " +
            "card = %d\n", drawIndex, row, card));

  }

  @Override
  public void discardDraw(int drawIndex) throws IllegalStateException {
    log.append(String.format("num1 = %d\n", drawIndex));

  }

  @Override
  public int getNumRows() {
    return 0;
  }

  @Override
  public int getNumDraw() {
    return 0;
  }

  @Override
  public int getRowWidth(int row) {
    return 0;
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {
    return false;
  }

  @Override
  public int getScore() throws IllegalStateException {
    return 0;
  }

  @Override
  public Card getCardAt(int row, int card) throws IllegalStateException {
    return null;
  }

  @Override
  public List<Card> getDrawCards() throws IllegalStateException {
    return null;
  }
}
