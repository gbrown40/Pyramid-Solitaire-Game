package cs3500.pyramidsolitaire.model.hw02;

/**
 * Represents a playing card.
 *
 */
public class Card {

  public int points;

  public int cover;

  /**
   * An enum to represent the Suit of the card.
   */
  public static enum Suit {
    Clubs, Spades, Diamonds, Hearts
  }

  public Suit suit;

  /**
   * Constructs a card in terms of its point value and suit.
   *
   * @param points the point value of the card
   * @param suit  suit of the card
   */
  public Card(int points, Suit suit, int cover) {
    if (points <= 0 || points > 13) {
      throw new IllegalArgumentException("Invalid point value");
    }

    this.points = points;
    this.suit = suit;
    this.cover = cover;
  }


  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof Card)) {
      return false;
    }

    Card c = (Card) obj;
    return (this.points == c.points) && (this.suit.equals(c.suit));
  }

  @Override
  public int hashCode() {
    int result = 17;
    result = 31 * result + points;
    result = 31 * result + suit.hashCode();
    return result;
  }

  @Override
  public String toString() {
    String suitString = "";
    String pointsString = "";

    if (this.suit.equals(suit.Clubs)) {
      suitString = "♣";
    }

    if (this.suit.equals(suit.Spades)) {
      suitString = "♠";
    }

    if (this.suit.equals(suit.Diamonds)) {
      suitString = "♦";
    }

    if (this.suit.equals(suit.Hearts)) {
      suitString = "♥";
    }

    if (this.points == 1) {
      pointsString = "A";
    }

    if (this.points == 11) {
      pointsString = "J";
    }

    if (this.points == 12) {
      pointsString = "Q";
    }

    if (this.points == 13) {
      pointsString = "K";
    }

    if (this.points < 11 && this.points != 1) {
      pointsString = "" + String.valueOf(this.points);
    }

    return pointsString + suitString;
  }


}
