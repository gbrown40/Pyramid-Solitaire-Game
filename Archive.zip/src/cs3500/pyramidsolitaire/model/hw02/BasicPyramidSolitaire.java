package cs3500.pyramidsolitaire.model.hw02;

import cs3500.pyramidsolitaire.model.hw04.APyramidSolitaire;

/**
 * The implementation of the model for playing a game of Pyramid Solitaire with the Card class for
 * its parameter.
 */
public class BasicPyramidSolitaire extends APyramidSolitaire {

  /**
   * Constructs a BasicPyramidSolitaire game and initializes it's values.
   */
  public BasicPyramidSolitaire() {
    super();

  }

}