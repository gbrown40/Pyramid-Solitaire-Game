package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;

/**
 * The implementation of the model for playing a game of Pyramid Solitaire with relaxed rules.
 */
public class RelaxedPyramidSolitaire extends APyramidSolitaire {


  /**
   * Constructs a BasicPyramidSolitaire game and initializes it's values.
   */
  public RelaxedPyramidSolitaire() {
    super();

  }


  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    this.mustStartGame();

    if (row1 < 0 || card1 < 0 || row1 > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card1 > this.pyramid.get(row2).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    }

    if (row2 < 0 || card2 < 0 || row2 > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card2 > this.pyramid.get(row2).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    }

    else {

      this.removeCheckValid(row1, card1, row2, card2);
    }
  }

  @Override
  protected void removeCheckValid(int row1, int card1, int row2, int card2) {
    Card c1 = this.pyramid.get(row1).get(card1);
    Card c2 = this.pyramid.get(row2).get(card2);

    if (!this.uncovered.contains(c1) && !this.uncovered.contains(c2)) {
      throw new IllegalArgumentException("Cannot remove cards");
    } else if ((this.uncovered.contains(c1) && this.uncovered.contains(c2)) ||
            this.isRemoveable(c1, c2, row1, card1, row2, card2)) {

      this.removeHelper(c1, c2.points, row1, card1, 0, false);
      this.removeHelper(c2, c1.points, row2, card2, 0, false);
    }

    else {
      throw new IllegalArgumentException("Cannot remove cards");
    }
  }

  //checks if cards can be removed
  private boolean isRemoveable(Card c1, Card c2, int row1, int card1, int row2, int card2) {
    boolean level = false;
    boolean cover = false;

    if (row2 == row1 + 1 && (card2 == card1 || card2 == card1 + 1)) {
      level = true;
    }

    if (c1.cover < 2) {
      cover = true;
    }

    return level && cover;


  }

  /**
   * Checks if a move can be made in the game.
   */
  @Override
  boolean canMakeMove() {

    //can any combination of uncovered cards equal 13?
    if (this.canMakeMoveHelper(this.uncovered, true)) {
      return true;
    }

    //can any combination of an uncovered card and a draw pile card equal 13?
    else if (this.canMakeMoveHelper(this.drawPile, false)) {
      return true;
    }

    //can any combination of an uncovered card and a card from the stock pile equal 13?
    else if (this.canMakeMoveHelper(this.stock, false)) {
      return true;
    }

    //can any of the uncovered cards be removed with one of the cards they are covering?
    else if (this.canMakeRelaxedMove()) {
      return true;
    }

    //can you discard a draw card?
    else {
      return this.drawPileNotNull();
    }

  }

  //finds which row a card is in
  private int findRow(Card c) {
    for (int i = 0; i < this.pyramid.size(); i++) {
      for (int j = 0; j < this.pyramid.get(i).size(); j++) {
        if (this.pyramid.get(i).get(j).equals(c)) {
          return i;
        }
      }
    }
    throw new IllegalArgumentException("Card not in pyramid");
  }

  //checks if a relaxed rules move can be made
  private boolean canMakeRelaxedMove() {
    for (int i = 0; i < this.uncovered.size(); i++) {
      Card c1 = this.uncovered.get(i);
      int row = this.findRow(c1);
      int card = 0;
      for (int j = 0; j < this.pyramid.get(i).size(); j++) {
        if (this.pyramid.get(row).get(j).equals(c1)) {
          card = j;
        }

      }


      if (row > 0) {
        if (card == 0) {
          Card c2 = this.pyramid.get(row - 1).get(card);
          if (c2.cover < 2 && (c2.points + c1.points == 13)) {
            return true;
          }
        }

        if (card == row - 1) {
          Card c2 = this.pyramid.get(row - 1).get(card - 1);
          if (c2.cover < 2 && (c2.points + c1.points == 13)) {
            return true;
          }

        }

        else {
          Card c2 = this.pyramid.get(row - 1).get(card);
          Card c3 = this.pyramid.get(row - 1).get(card - 1);
          if (c2.cover < 2 && (c2.points + c1.points == 13)) {
            return true;
          }
          else if (c3.cover < 2 && (c3.points + c1.points == 13)) {
            return true;
          }

        }


      }
    }
    return false;
  }


}
