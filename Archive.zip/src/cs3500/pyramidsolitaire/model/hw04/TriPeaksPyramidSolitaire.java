package cs3500.pyramidsolitaire.model.hw04;

import java.util.ArrayList;
import java.util.List;

import cs3500.pyramidsolitaire.model.hw02.Card;

/**
 * The implementation of the model for playing a game of Pyramid Solitaire with three peaks.
 */
public class TriPeaksPyramidSolitaire extends APyramidSolitaire {

  private TriPeaksPyramidSolitaire.Status status;

  /**
   * Constructs a BasicPyramidSolitaire game and initializes it's values.
   */
  public TriPeaksPyramidSolitaire() {
    super();

  }

  @Override
  public List<Card> getDeck() {
    int deckSize = 2;
    return this.getDeckHelper(deckSize);
  }

  @Override
  int getNumCards(int numRows) {
    int finalLength = numRows + 2 * (numRows / 2);
    int firstLength = finalLength - numRows + 1;
    int count = 3;
    int cards = 0;

    for (int i = 0; i < numRows; i++) {
      if (count < firstLength) {
        cards += count;
        firstLength++;
        count += 3;
      } else {
        cards += firstLength;
        firstLength++;
        count += 3;
      }
    }
    return cards;

  }

  @Override
  protected void startGameHelper(List<Card> deck, int numRows,
                                 int numDraw, int deckSize) {
    if (numDraw + this.getNumCards(numRows) > 104 || numDraw < 0 || numRows <= 1) {
      throw new IllegalArgumentException("Invalid combo of rows and draw cards");
    }
    //index in deck
    int finalLength = numRows + 2 * (numRows / 2);
    int firstLength = finalLength - numRows + 1;
    int numCards = 3;
    int index = 0;

    for (int i = 1; i < numRows; i++) {

      if (numCards < firstLength) { //add nulls in for blank spaces
        ArrayList<Card> row = new ArrayList<Card>();
        int empty = firstLength - numCards;
        int space = empty / 2;

        for (int j = 0; j < 3; j++) { // three peaks
          for (int k = 0; k < i; k++) { // each pyramid contributes length of row
            row.add(deck.get(index));
            this.covered.add(deck.get(index));
            this.score += deck.get(index).points;
            index++;
          }
          if (j < 2) { //doesnt add nulls to the end
            for (int l = 0; l < space; l++) {
              row.add(null);
            }
          }

        }

        firstLength++;
        numCards += 3;
      } else { // no blank spaces
        ArrayList<Card> row = new ArrayList<Card>();
        for (int j = 0; j < firstLength; j++) {
          if (i == numRows) {
            //bottom row cards are not covered by any other cards
            this.uncovered.add(deck.get(index));
          } else {
            this.covered.add(deck.get(index));
          }

          row.add(deck.get(index));
          this.score += deck.get(index).points;
          index++;

        }
        this.pyramid.add(row);
        firstLength++;
      }
    }

    //add to draw pile
    for (int k = 0; k < numDraw; k++) {
      if (index < deck.size()) {
        this.drawPile.add(deck.get(index));
        index++;
      }
    }

    //add remaining to stock
    if (index < deck.size()) {
      this.stock.add(deck.get(index));
      index++;
    }
  }

  /**
   * Checks if given deck is a standard deck (52 cards, one for each number suit combo).
   *
   * @param deck list of cards
   */
  @Override
  boolean isValid(List<Card> deck) {

    return isValidHelper(2, 4, deck);

  }
}
