package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;



/**
 * a class to return different types of pyramid solitaire games.
 */
public final class PyramidSolitaireCreator {

  /**
   * an enum to represent different game types.
   */
  public enum GameType {
    BASIC, RELAXED, TRIPEAKS
  }

  GameType gt;


  public PyramidSolitaireCreator() {
    //empty constructor to use for testing
  }

  /**
   * returns different types of pyramid solitaire games based on the gametype.
   */
  public static APyramidSolitaire create(GameType type) {
    switch (type) {
      case BASIC:
        return new BasicPyramidSolitaire();
      case RELAXED:
        return new RelaxedPyramidSolitaire();
      case TRIPEAKS:
        return new TriPeaksPyramidSolitaire();
      default:
        throw new IllegalArgumentException("Not valid game type");
    }
  }



}
