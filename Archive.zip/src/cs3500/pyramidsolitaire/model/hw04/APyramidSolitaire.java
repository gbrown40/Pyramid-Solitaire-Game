package cs3500.pyramidsolitaire.model.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * an abstract class for implementing different types of pyramid solitaire games.
 */
public abstract class APyramidSolitaire implements PyramidSolitaireModel<Card> {

  protected int score;
  //pyramid representation of cards in play
  protected ArrayList<ArrayList<Card>> pyramid;
  //stock pile
  protected ArrayList<Card> stock;
  //visible draw pile that player can use
  protected ArrayList<Card> drawPile;
  protected int rows;
  protected int numDrawPile;
  //Cards that are not covered and thus can be removed
  protected ArrayList<Card> uncovered;
  //Cards that are not covered and thus can't be removed
  protected ArrayList<Card> covered;

  /**
   * a constructor for APyramidSolitaire.
   */
  public APyramidSolitaire() {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stock = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.uncovered = new ArrayList<Card>();
    this.covered = new ArrayList<Card>();
    this.status = status.BeforeGame;
    this.score = 0;
    this.rows = 0;
    this.numDrawPile = 0;
  }

  /**
   * An enum to represent the Status of the game.
   */
  static enum Status {
    BeforeGame, Playing, Over
  }

  protected APyramidSolitaire.Status status;

  @Override
  public List<Card> getDeck() {
    int deckSize = 1;
    return this.getDeckHelper(deckSize);

  }

  protected List<Card> getDeckHelper(int deckSize) {
    List<Card> initDeck = new ArrayList<Card>();

    boolean spades = true;
    boolean clubs = false;
    boolean hearts = false;
    boolean diamonds = false;


    for (int i = 0; i < deckSize; i++) {
      for (int j = 1; j < 5; j++) {
        for (int k = 1; k < 14; k++) {
          if (j == 2) {
            spades = false;
            clubs = true;
            hearts = false;
            diamonds = false;
          }

          if (j == 3) {
            spades = false;
            clubs = false;
            hearts = true;
            diamonds = false;
          }

          if (j == 4) {
            spades = false;
            clubs = false;
            hearts = false;
            diamonds = true;
          }

          if (clubs) {
            Card newCard = new Card(k, Card.Suit.Clubs, 2);
            initDeck.add(newCard);

          }

          if (spades) {
            Card newCard = new Card(k, Card.Suit.Spades, 2);
            initDeck.add(newCard);

          }

          if (diamonds) {
            Card newCard = new Card(k, Card.Suit.Diamonds, 2);
            initDeck.add(newCard);

          }

          if (hearts) {
            Card newCard = new Card(k, Card.Suit.Hearts, 2);
            initDeck.add(newCard);
          }


        }

      }
    }
    return initDeck;

  }

  void initVals() {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stock = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.uncovered = new ArrayList<Card>();
    this.covered = new ArrayList<Card>();
    this.status = status.BeforeGame;
    this.score = 0;
    this.rows = 0;
    this.numDrawPile = 0;
  }

  /**
   * Returns the number of elements in a pyramid.
   *
   * @param numRows is the number of rows in the pyramid to be returned.
   */
  int getNumCards(int numRows) {
    int count = 0;
    for (int i = 0; i < numRows; i++) {
      count += i + 1;
    }
    return count;

  }


  @Override
  public void startGame(List<Card> deck, boolean shouldShuffle, int numRows, int numDraw) {

    this.initVals();

    if (!this.isValid(deck)) {
      throw new IllegalArgumentException("Deck is not valid");
    }

    //shuffles before checking for valid deck, ensures that shuffling method
    //returns a valid deck, otherwise method will throw an IllegalArgumentException
    if (shouldShuffle) {
      Collections.shuffle(deck);
    }

    this.status = status.Playing;

    this.startGameHelper(deck, numRows, numDraw, 52);


    this.rows = numRows;
    this.numDrawPile = numDraw;
  }

  protected void startGameHelper(List<Card> deck, int numRows,
                                 int numDraw, int deckSize) {

    if (numDraw + this.getNumCards(numRows) > deckSize || numDraw < 0 || numRows <= 1) {
      throw new IllegalArgumentException("Invalid combo of rows and draw cards");
    }
    //index in deck
    int index = 0;
    int pyrSize = this.getNumCards(numRows);
    int stockSize = deck.size() - pyrSize - numDraw;

    //i represents current row number
    for (int i = 1; i <= numRows; i++) {
      ArrayList<Card> row = new ArrayList<Card>();
      //add number of cards from deck equal to row number to row
      for (int j = 0; j < i; j++) {
        if (i == numRows) {
          //bottom row cards are not covered by any other cards
          this.uncovered.add(deck.get(index));
        }
        row.add(deck.get(index));
        this.covered.add(deck.get(index));
        this.score += deck.get(index).points;
        index++;
      }
      this.pyramid.add(row);
    }

    //add to draw pile
    for (int k = 0; k < numDraw; k++) {
      if (index < deck.size()) {
        this.drawPile.add(deck.get(index));
        index++;
      }
    }

    //add remaining to stock
    for (int l = 0; l < stockSize; l++) {
      if (index < deck.size()) {
        this.stock.add(deck.get(index));
        index++;
      }
    }

  }


  /**
   * Checks if given deck is a standard deck (52 cards, one for each number suit combo, or some
   * other set of rules set by a pyramid solitaire game).
   *
   * @param deck list of cards
   */
  boolean isValid(List<Card> deck) {
    return this.isValidHelper(1, 4, deck);


  }

  protected boolean isValidHelper(int suit, int countNum, List<Card> deck) {
    if (deck == null) {
      return false;
    }

    for (int i = 0; i < deck.size(); i++) {
      if (deck.get(i) == null) {
        return false;
      }
    }

    if (deck.isEmpty()) {
      return false;
    } else {

      boolean ace = enoughCards(1, deck, suit, countNum);
      boolean twos = enoughCards(2, deck, suit, countNum);
      boolean threes = enoughCards(3, deck, suit, countNum);
      boolean fours = enoughCards(4, deck, suit, countNum);
      boolean fives = enoughCards(5, deck, suit, countNum);
      boolean sixes = enoughCards(6, deck, suit, countNum);
      boolean sevens = enoughCards(7, deck, suit, countNum);
      boolean eights = enoughCards(8, deck, suit, countNum);
      boolean nines = enoughCards(9, deck, suit, countNum);
      boolean tens = enoughCards(10, deck, suit, countNum);
      boolean jack = enoughCards(11, deck, suit, countNum);
      boolean queen = enoughCards(12, deck, suit, countNum);
      boolean king = enoughCards(13, deck, suit, countNum);

      return (deck.size() == 52) && ace && twos && threes && fours && fives
              && sixes & sevens && eights && nines && tens && jack && queen && king;
    }

  }

  /**
   * Checks if deck has four of a card of a certain value (one for each suit).
   *
   * @param val  score to be found
   * @param deck list of all the cards to look through
   */
  boolean enoughCards(int val, List<Card> deck, int suit, int countNum) {
    int count = 0;
    int clubCount = 0;
    int spadeCount = 0;
    int diamondCount = 0;
    int heartCount = 0;

    for (int i = 0; i < deck.size(); i++) {
      Card curCard = deck.get(i);

      if (val == curCard.points) {
        count++;

        if (curCard.suit.equals(Card.Suit.Clubs)) {
          clubCount++;
        }

        if (curCard.suit.equals(Card.Suit.Spades)) {
          spadeCount++;
        }

        if (curCard.suit.equals(Card.Suit.Diamonds)) {
          diamondCount++;
        }

        if (curCard.suit.equals(Card.Suit.Hearts)) {
          heartCount++;
        }

      }
    }
    //System.out.println(count + clubCount + spadeCount + diamondCount + heartCount);
    return (count == countNum) && (clubCount == suit) && (spadeCount == suit)
            && (diamondCount == suit) && (heartCount == suit);
  }


  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    this.mustStartGame();

    if (row1 < 0 || card1 < 0 || row1 > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card1 > this.pyramid.get(row2).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    }

    if (row2 < 0 || card2 < 0 || row2 > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card2 > this.pyramid.get(row2).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else {

      this.removeCheckValid(row1, card1, row2, card2);

    }
  }

  @Override
  public void remove(int row, int card) throws IllegalStateException {
    this.mustStartGame();

    if (row < 0 || card < 0 || row > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card > this.pyramid.get(row).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else {
      Card c1 = this.pyramid.get(row).get(card);

      if (!this.uncovered.contains(c1)) {
        throw new IllegalArgumentException("Cannot remove cards");
      } else {

        this.removeHelper(c1, 0, row, card, 0, false);
      }
    }

  }

  protected void removeCheckValid(int row1, int card1, int row2, int card2) {
    Card c1 = this.pyramid.get(row1).get(card1);
    Card c2 = this.pyramid.get(row2).get(card2);

    if (!this.uncovered.contains(c1) || !this.uncovered.contains(c2)) {
      throw new IllegalArgumentException("Cannot remove cards");
    } else {

      this.removeHelper(c1, c2.points, row1, card1, 0, false);
      this.removeHelper(c2, c1.points, row2, card2, 0, false);
    }
  }


  @Override
  public void removeUsingDraw(int drawIndex, int row, int card) throws IllegalStateException {
    this.mustStartGame();

    if (drawIndex > this.drawPile.size() - 1 || drawIndex < 0 || row < 0 || card < 0
            || row > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else if (card > this.pyramid.get(row).size() - 1) {
      throw new IllegalArgumentException("Invalid indices");
    } else {
      Card c1 = this.pyramid.get(row).get(card);
      Card c2 = this.drawPile.get(drawIndex);

      if (!this.uncovered.contains(c1)) {
        throw new IllegalArgumentException("Cannot remove cards");
      } else {

        this.removeHelper(c1, c2.points, row, card, drawIndex, true);
      }
    }


  }

  protected void updateCover(int row, int card) {
    //only relevant for relaxed pyramid solitaire class
    //I would have made it a helper in relaxed pyramid solitaire, but
    //then i would have had to override removeHelper and that seemed excessive
  }

  /**
   * Used to abstract for both removes and removeUsingDraw.
   */
  void removeHelper(Card c1, int c2, int row, int card, int drawI, boolean draw) {
    if (c1.points + c2 != 13) {
      throw new IllegalArgumentException("card cannot be removed");
    } else {
      if (row >= 0 && card >= 0 && row < this.pyramid.size()) {
        if (card < this.pyramid.get(row).size()) {
          this.pyramid.get(row).set(card, null);
          this.updateCover(row, card);
        }
      }

      //0,0
      if (card == 0 && row == 0) {
        this.status = APyramidSolitaire.Status.Over;

      }

      //In the middle for both
      else if (row > 0 && row < this.pyramid.size()
              && card > 0 && card < this.pyramid.get(row).size() - 1) {

        if (this.pyramid.get(row).get(card - 1) == null) {
          this.uncovered.add(this.pyramid.get(row - 1).get(card - 1));
        }
        if (this.pyramid.get(row).get(card + 1) == null) {
          this.uncovered.add(this.pyramid.get(row - 1).get(card));
        }

      }

      //first column, not first row
      else if (row > 0 && card == 0) {
        if (this.pyramid.get(row).get(card + 1) == null) {
          this.uncovered.add(this.pyramid.get(row - 1).get(card));
        }

      } else if (card == this.pyramid.get(row).size() - 1 && card > 0 && row > 0) {
        if (this.pyramid.get(row).get(card - 1) == null) {
          this.uncovered.add(this.pyramid.get(row - 1).get(card - 1));
        }

      }

      if (draw) {
        if (drawI > 0 && drawI < this.drawPile.size()) {
          this.discardDraw(drawI);
        }
      }

      this.score -= c1.points;


    }
  }

  @Override
  public void discardDraw(int drawIndex) throws IllegalStateException {
    this.mustStartGame();

    if (drawIndex < 0 || drawIndex >= this.drawPile.size()) {
      throw new IllegalArgumentException("Invalid Index");
    } else if (this.drawPile.get(drawIndex) == null) {
      throw new IllegalArgumentException("No card there");
    }

    else if (this.stock.size() > 0) {
      Card c = this.stock.get(0);
      this.drawPile.set(drawIndex, c);
      this.stock.remove(c);
    } else {
      this.drawPile.set(drawIndex, null);
    }

  }


  @Override
  public int getNumRows() {
    if (this.status == APyramidSolitaire.Status.BeforeGame) {
      return -1;
    } else {
      return this.rows;
    }
  }

  @Override
  public int getNumDraw() {
    if (this.status == APyramidSolitaire.Status.BeforeGame) {
      return -1;
    } else {
      return numDrawPile;
    }
  }

  @Override
  public int getRowWidth(int row) {
    this.mustStartGame();

    if (row >= this.pyramid.size() || row < 0) {
      throw new IllegalArgumentException("No row there");
    }

    return this.pyramid.get(row).size();
  }

  void mustStartGame() {
    if (this.status.equals(status.BeforeGame)) {
      throw new IllegalStateException("must start game");
    }
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {

    this.mustStartGame();

    if (this.score == 0) {
      this.status = status.Over;
    }

    else if (!this.canMakeMove()) {
      this.status = status.Over;
    }

    return this.status == status.Over;

  }

  boolean drawPileNotNull() {
    for (int i = 0; i < this.drawPile.size(); i++) {
      if (this.drawPile.get(i) != null) {
        return true;
      }
    }
    return false;
  }

  /**
   * Checks if a move can be made in the game.
   */
  boolean canMakeMove() {

    //can any combination of uncovered cards equal 13?
    if (this.canMakeMoveHelper(this.uncovered, true)) {
      return true;
    }

    //can any combination of an uncovered card and a draw pile card equal 13?
    else if (this.canMakeMoveHelper(this.drawPile, false)) {
      return true;
    }

    //can any combination of an uncovered card and a card from the stock pile equal 13?
    else if (this.canMakeMoveHelper(this.stock, false)) {
      return true;
    }

    //can you discard a draw card?
    else {
      return this.drawPileNotNull();
    }

  }

  /**
   * Used to abstract for canMakeMove.
   *
   * @param l         list to loop through cards
   * @param duplicate whether or not the two list being looped through are the same or not
   */
  boolean canMakeMoveHelper(List<Card> l, boolean duplicate) {
    for (Card c1 : this.uncovered) {
      for (int i = 0; i < l.size(); i++) {

        if (duplicate) {
          //don't check it against itself if same list
          if (this.uncovered.indexOf(c1) == i) {
            continue;
          }
        }
        if (l.get(i) == null) {
          continue;
        } else if (c1.points + l.get(i).points == 13) {
          return true;

        }
      }

    }
    return false;
  }

  @Override
  public int getScore() throws IllegalStateException {
    this.mustStartGame();
    return this.score;
  }

  @Override
  public Card getCardAt(int row, int card) throws IllegalStateException {

    this.mustStartGame();
    if (row < 0 || card < 0 || row >= this.pyramid.size()) {
      throw new IllegalArgumentException("Invalid Index");
    } else if (card >= this.pyramid.get(row).size()) {
      throw new IllegalArgumentException("Invalid Index");
    }

    return this.pyramid.get(row).get(card);
  }

  @Override
  public List<Card> getDrawCards() throws IllegalStateException {
    this.mustStartGame();
    return this.drawPile;
  }

  /**
   * Converts game to a string representation.
   */
  @Override
  public String toString() {
    String pyramid = "";

    if (this.status.equals(APyramidSolitaire.Status.Over)) {
      if (this.score == 0) {
        return "You win!";
      } else {
        return "Game over. Score: " + this.score;
      }
    }


    if (this.status.equals(APyramidSolitaire.Status.Playing)) {

      for (int i = 0; i < this.pyramid.size(); i++) {
        ArrayList<Card> row = this.pyramid.get(i);
        String cardRow = "";

        for (int j = 0; j <= row.size(); j++) {

          String left = "";
          if (j == 0) {
            for (int k = 0; k < ((this.rows * 2) - 1) - (2 * (row.size() - 2)) - 3; k++) {
              left += " ";
            }
          }

          if (j == row.size()) {
            cardRow += "\n";
          } else if (row.get(j) == null) {
            cardRow = cardRow + left + "   ";
          } else if (j == row.size() - 1) {
            String card = row.get(j).toString();
            cardRow = cardRow + left + card;
          } else {
            String card = row.get(j).toString();
            cardRow = cardRow + left + card + " ";
            if (card.length() == 2) {
              cardRow += " ";
            }
          }

        }
        pyramid += cardRow;
      }

      pyramid = pyramid + "Draw: " + this.drawDiscard();
      return pyramid;

    } else {
      return "";
    }

  }


  /**
   * Converts draw pile to a string representation. Null values are not drawn.
   */
  String drawDiscard() {
    String draw = "";
    for (int i = 0; i < this.drawPile.size(); i++) {

      if (i == this.drawPile.size() - 1) {
        if (this.drawPile.get(i) == null) {
          continue;

        } else {
          draw += this.drawPile.get(i).toString();
        }
      } else {
        if (this.drawPile.get(i) == null) {
          continue;

        } else {
          draw = draw + this.drawPile.get(i).toString() + ", ";
        }
      }
    }
    return draw;
  }

}
