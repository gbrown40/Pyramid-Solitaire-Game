package cs3500.pyramidsolitaire.controller;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

import java.util.List;


/**
 * The model for the controller of Pyramid Solitaire: this transmits information
 * between the model and the view and plays the game.
 *
 * @param <K> the type of cards this model uses
 */
public interface PyramidSolitaireController<K> {

  /**
   * Plays a new game of Pyramid Solitaire using the provided model,
   * using the startGame method on the model.
   *
   * @param model the pyramid solitaire game model
   * @param deck the deck of cards used in the model
   * @param shuffle whether or not the cards are shuffled
   * @param numRows number of rows in the pyramid
   * @param numDraw number of draw cards in the game
   * @throws IllegalArgumentException if the model is null
   * @throws IllegalStateException if the controller is unable to successfully
   * receive input or transmit output, or if the game cannot be started
   */
  <K> void playGame(PyramidSolitaireModel<K> model, List<K> deck,
                    boolean shuffle, int numRows, int numDraw);
}
