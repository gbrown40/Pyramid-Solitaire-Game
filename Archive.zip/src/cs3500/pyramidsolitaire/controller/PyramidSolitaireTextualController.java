package cs3500.pyramidsolitaire.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

/**
 * The implementation of the controller for playing a game of Pyramid Solitaire.
 */
public class PyramidSolitaireTextualController implements PyramidSolitaireController {

  private Readable rd;
  private Appendable ap;

  /**
   * Constructs a PyramidSolitaireTextualController and initializes it's values.
   */
  public PyramidSolitaireTextualController(Readable rd, Appendable ap)
          throws IllegalArgumentException {
    if (rd == null || ap == null) {
      throw new IllegalArgumentException("Values cannot be null.");
    }
    this.rd = rd;
    this.ap = ap;
  }

  private boolean isNumeric(String strNum) {
    try {
      int d = Integer.parseInt(strNum);
    } catch (NumberFormatException | NullPointerException e) {
      return false;
    }
    return true;
  }


  @Override
  public void playGame(PyramidSolitaireModel model, List deck,
                       boolean shuffle, int numRows, int numDraw) {

    if (model == null) { // throws an exception when the given model is null
      throw new IllegalArgumentException("Given Model is null.");
    }

    try {
      model.startGame(deck, shuffle, numRows, numDraw);
    } catch (IllegalStateException | IllegalArgumentException e) {
      throw new IllegalStateException("Invalid Game");
    }

    Scanner scan = new Scanner(this.rd);

    while (!model.isGameOver() && scan.hasNext()) {

      PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model, this.ap);

      String str = scan.next();

      this.tryCatch(model.toString() + "\n");
      this.tryCatch("\nScore: " + model.getScore() + "\n");

      //flags for keeping track of the key string values
      boolean rm1 = false;
      boolean rm2 = false;
      boolean rmwd = false;
      boolean dd = false;

      //arraylists to keep track of card vals to call model functions with
      ArrayList<Integer> rm1List = new ArrayList<Integer>();
      ArrayList<Integer> rm2List = new ArrayList<Integer>();
      ArrayList<Integer> rmwdList = new ArrayList<Integer>();

      if (str.equals("q") || str.equals("Q")) {
        this.tryCatch("Game quit!\nState of game when quit:\n" + model.toString() + "\n"
                + "Score: " + model.getScore() + "\n");
      } else if (str.equals("rm1")) {
        rm1 = true;

      } else if (str.equals("rm2")) {
        rm2 = true;

      } else if (str.equals("rmwd")) {
        rmwd = true;

      } else if (str.equals("dd")) {
        dd = true;

      } else if (rm1) {
        this.playGameHelper(str, rm1List, model, true,
                false, false, false, rm1, 2);

      } else if (rm2) {
        this.playGameHelper(str, rm2List, model, false,
                true, false, false, rm2, 4);

      } else if (rmwd) {
        this.playGameHelper(str, rmwdList, model, false,
                false, true, false, rmwd, 3);

      } else if (dd) {
        this.playGameHelper(str, rmwdList, model, false,
                false, true, dd, dd, 0);

      } else {
        this.tryCatch("Invalid input");
      }
    }

    // once the game is over, try to append the ending message
    // if it is not appendable for some reason, catches the IOException an throws
    // an illegal state exception
    if (model.isGameOver()) {
      this.tryCatch(model.toString() + "\n");
    }

  }

  //tries to make a move based on which boolean (one, two, three, or four) is true
  private void playGameHelper(String str, ArrayList<Integer> tracker, PyramidSolitaireModel model,
                      boolean one, boolean two, boolean three, boolean four,
                      boolean curStr, int size) {
    if (this.isNumeric(str)) {
      int newVal = Integer.valueOf(str) - 1;
      tracker.add(newVal);

      if (four) {
        try {
          model.discardDraw(newVal);
        } catch (IllegalStateException | IllegalArgumentException e) {
          throw new IllegalStateException("Unable to transmit information");
        }
        four = false;
      }
      if (tracker.size() == size) {
        try {
          if (one) {
            model.remove(tracker.get(0), tracker.get(1));
          }
          if (two) {
            model.remove(tracker.get(0), tracker.get(1), tracker.get(2), tracker.get(3));
          }
          if (three) {
            model.removeUsingDraw(tracker.get(0), tracker.get(1), tracker.get(2));
          }
        } catch (IllegalStateException | IllegalArgumentException e) {
          throw new IllegalStateException("Unable to transmit information");
        }
        tracker.clear();
        curStr = false;
      }

    } else {
      this.tryCatch("Invalid input");
    }
  }


  /**
   * A helper method used to append a message to the appendable.
   */
  private void tryCatch(String tc) {
    try {
      this.ap.append(tc);
    } catch (IOException e) {
      throw new IllegalStateException("Illegal State");
    }
  }


}
