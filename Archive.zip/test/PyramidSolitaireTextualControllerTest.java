
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireController;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.ConfirmInputsModel;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

/**
 * A class used for testing the controller.
 */
public class PyramidSolitaireTextualControllerTest {

  PyramidSolitaireModel<Card> exampleModelBasic;
  PyramidSolitaireModel<Card> exampleModelBasic2;
  PyramidSolitaireModel<Card> exampleModelRelaxed;
  PyramidSolitaireModel<Card> exampleModelTri;
  List<Card> validDeck;
  List<Card> validDeck2;
  List<Card> emptyDeck;
  List<Card> invalidNonEmpty;

  void init() {
    exampleModelBasic = new BasicPyramidSolitaire();
    exampleModelBasic2 = new BasicPyramidSolitaire();
    exampleModelRelaxed = new RelaxedPyramidSolitaire();
    exampleModelTri = new TriPeaksPyramidSolitaire();
    validDeck = exampleModelBasic.getDeck();
    validDeck2 = exampleModelTri.getDeck();
    emptyDeck = new ArrayList<Card>();
    invalidNonEmpty = new ArrayList<Card>();
  }

  /**
   * Helper method used for later tests that test interactions.
   * @param model the model to test the interactions on
   * @param interactions the user-controller interactions
   * @param numRows the number of rows to make the pyramid
   * @param numDraw the number of draw cards to make the pyramid
   */
  public void testInteractions(PyramidSolitaireModel model, Interaction[] interactions,
                               int numRows, int numDraw) {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireController controller =
            new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, this.validDeck, false, numRows, numDraw);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }


  //all input tests only tested on a mock model, not any specific one
  @Test
  public void testInputs() throws IOException {
    Readable in = new StringReader("rm1 3 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = 3, card = 4\n", log.toString());
  }

  @Test
  public void testInputs2() throws IOException {
    Readable in = new StringReader("rm2 3 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = 3, card1 = 4, row2 = 1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs3() throws IOException {
    Readable in = new StringReader("rmwd 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4, row = 1, card = 2\n", log.toString());
  }

  @Test
  public void testInputs4() throws IOException {
    Readable in = new StringReader("dd 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4\n", log.toString());
  }

  @Test
  public void testInputs5() throws IOException {
    Readable in = new StringReader("rm1 -3 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = -3, card = 4\n", log.toString());
  }

  @Test
  public void testInputs6() throws IOException {
    Readable in = new StringReader("rm1 3 -4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = 3, card = -4\n", log.toString());
  }

  @Test
  public void testInputs7() throws IOException {
    Readable in = new StringReader("rm1 -3 -4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = -3, card = -4\n", log.toString());
  }

  @Test
  public void testInputs8() throws IOException {
    Readable in = new StringReader("rm1 3 y 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = 3, card = 4\n", log.toString());
  }

  @Test
  public void testInputs9() throws IOException {
    Readable in = new StringReader("rm1 3 4 y");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = 3, card = 4\n", log.toString());
  }

  @Test
  public void testInputs10() throws IOException {
    Readable in = new StringReader("y rm1 3 4 /");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row = 3, card = 4\n", log.toString());
  }

  @Test
  public void testInputs11() throws IOException {
    Readable in = new StringReader("rm2 -3 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = -3, card1 = 4, row2 = 1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs12() throws IOException {
    Readable in = new StringReader("rm2 3 i 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = 3, card1 = 4, row2 = 1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs13() throws IOException {
    Readable in = new StringReader("rm2 3 4 -1 2 p");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = 3, card1 = 4, row2 = -1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs14() throws IOException {
    Readable in = new StringReader(" rm2 3 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = 3, card1 = 4, row2 = 1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs15() throws IOException {
    Readable in = new StringReader("u rm2 3 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("row1 = 3, card1 = 4, row2 = 1, card2 = 2\n", log.toString());
  }

  @Test
  public void testInputs16() throws IOException {
    Readable in = new StringReader("rmwd -4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = -4, row = 1, card = 2\n", log.toString());
  }

  @Test
  public void testInputs17() throws IOException {
    Readable in = new StringReader("rmwd o 4 -1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4, row = -1, card = 2\n", log.toString());
  }

  @Test
  public void testInputs18() throws IOException {
    Readable in = new StringReader("rmwd 4 1 -2 k ");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4, row = 1, card = -2\n", log.toString());
  }

  @Test
  public void testInputs19() throws IOException {
    Readable in = new StringReader("n rmwd 4 1 2");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4, row = 1, card = 2\n", log.toString());
  }

  @Test
  public void testInputs20() throws IOException {
    Readable in = new StringReader("dd -4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = -4\n", log.toString());
  }

  @Test
  public void testInputs21() throws IOException {
    Readable in = new StringReader("j dd 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4\n", log.toString());
  }

  @Test
  public void testInputs22() throws IOException {
    Readable in = new StringReader("dd a 4");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4\n", log.toString());
  }

  @Test
  public void testInputs23() throws IOException {
    Readable in = new StringReader("dd 4 o");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("drawIndex = 4\n", log.toString());
  }

  @Test
  public void testInputs24() throws IOException {
    Readable in = new StringReader("yzr");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("\n", log.toString());
  }

  @Test
  public void testInputs25() throws IOException {
    Readable in = new StringReader("");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("\n", log.toString());
  }

  @Test
  public void testInputs26() throws IOException {
    Readable in = new StringReader(" ");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, this.validDeck, false, 5, 3);
    assertEquals("\n", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInputsNullDeck() throws IOException {
    Readable in = new StringReader(" ");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(model, null, false, 5, 3);
    assertEquals("\n", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInputsNullModel() throws IOException {
    Readable in = new StringReader(" ");
    StringBuilder dontCareOutput = new StringBuilder();
    PyramidSolitaireController<Card> controller =
            new PyramidSolitaireTextualController(in, dontCareOutput);

    StringBuilder log = new StringBuilder();
    PyramidSolitaireModel<Card> model = new ConfirmInputsModel(log);

    controller.playGame(null, this.validDeck, false, 5, 3);
    assertEquals("\n", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullReadable() {
    this.init();
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController exNullRead = new PyramidSolitaireTextualController(null, out);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullAppendable() {
    this.init();
    String test = "4 6 4 4 q";
    StringReader in = new StringReader(test);
    PyramidSolitaireController exNullAppend = new PyramidSolitaireTextualController(in, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullReadAndAppend() {
    this.init();
    PyramidSolitaireController exNullReadAndAppend =
        new PyramidSolitaireTextualController(null, null);
  }

  @Test
  public void testBasicInputStringQuit1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("q 2 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringQuit() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("Q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputStringQuit2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 q 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 3, 3);

  }

  @Test
  public void testBasicInputStringQuit3() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringQuit4() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }


  @Test
  public void testBasicInputString1q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputStringRowQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 q 3 \n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputStringCardQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputString2q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringInvalid() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 2 t\n"),
        new PrintInteraction("Invalid move. Play again.\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputString3q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 3, 4);
  }


  @Test
  public void testBasicInputString4q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRm2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRmwd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 3, 4);
  }


  @Test
  public void testBasicInputStringDd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringrm1Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm1 5 3\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);

  }

  @Test
  public void testBasicInputStringRm2Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm2 5 2 5 4\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRmwdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 3, 4);
  }


  @Test
  public void testBasicInputStringDdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }


  @Test
  public void testBasicInputStringRm1InvalidRowq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 ? 5 / 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRm2InvalidCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 r 2 5 4\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRmwdInvalidDrawCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd k 1 i 3 3\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 3, 4);
  }

  @Test
  public void testBasicInputStringRm1InvalidDdq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 i dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicGameOver() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicGameOverBogus() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 dd -9 rm1 29 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicGameOverWin() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 1 5 3 rm1 5 2 rmwd 3 4 2 dd 8 rm1 4 1 4 3\n"),
        new PrintInteraction("You win!")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringRm2Rm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 3 5 4 rm1 5 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputStringInvalidQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("a a a a Q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputEmpty() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputBlank() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction(" \n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test
  public void testBasicInputNonsense() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("zxr\n"),
        new PrintInteraction(this.exampleModelBasic.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelBasic, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1InvalidRow() {
    this.init();
    String test = "rm1 20 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1InvalidCard() {
    this.init();
    String test = "rm1 1 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1InvalidRowAndCard() {
    this.init();
    String test = "rm1 20 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1NegRow() {
    this.init();
    String test = "rm1 -2 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1NegCard() {
    this.init();
    String test = "rm1 2 -1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRmwdNegRowAndCardAndInvalid() {
    this.init();
    String test = "rmwd -7 -3 a -8";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1NegRowAndCardAndInvalid() {
    this.init();
    String test = "rmw2 -7 -3 a -8 2";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRmw2Invalid() {
    this.init();
    String test = "rmw2 4 6 4 3 q";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 3);
  }


  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1InvalidDeck() {
    this.init();
    String test = "rm1 2 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.invalidNonEmpty,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputString21() {
    this.init();
    String test = "rm2 1 1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.emptyDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1TooHighNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 10, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1NegDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, -1);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1TooLowNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 1, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1ZeroRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, 0, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringRm1NegRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringEmptyString() {
    this.init();
    String test = "";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringInvalidString() {
    this.init();
    String test = "s";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringOnlyNums() {
    this.init();
    String test = "1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicInputStringZeroDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, true, 5, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testBasicAppendable() {
    this.init();
    String test = "6 7 5 4 q";
    StringReader in = new StringReader(test);
    Appendable out = new AppendableImpl();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelBasic, this.validDeck, false, 5, 50);
  }


  @Test
  public void testRelInputStringQuit1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("q 2 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringQuit() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("Q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputStringQuit2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 q 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 3, 3);

  }

  @Test
  public void testRelInputStringQuit3() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringQuit4() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }


  @Test
  public void testRelInputString1q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputStringRowQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 q 3 \n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputStringCardQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputString2q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringInvalid() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 2 t\n"),
        new PrintInteraction("Invalid move. Play again.\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputString3q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 3, 4);
  }


  @Test
  public void testRelInputString4q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 19\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRm2Relaxed() {
    this.init();
    //successfully completes relaxed move
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 6 0 rm2 6 1 5 0\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 35\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRm2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRmwd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 3, 4);
  }


  @Test
  public void testRelInputStringDd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringrm1Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm1 5 3\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);

  }

  @Test
  public void testRelInputStringRm2Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm2 5 2 5 4\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRmwdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 3, 4);
  }


  @Test
  public void testRelInputStringDdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }


  @Test
  public void testRelInputStringRm1InvalidRowq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 ? 5 / 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRm2InvalidCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 r 2 5 4\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testInputStringRmwdInvalidDrawCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd k 1 i 3 3\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 3, 4);
  }

  @Test
  public void testRelInputStringRm1InvalidDdq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 i dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelGameOver() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelGameOverBogus() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 dd -9 rm1 29 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelGameOverWin() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 1 5 3 rm1 5 2 rmwd 3 4 2 dd 8 rm1 4 1 4 3\n"),
        new PrintInteraction("You win!")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringRm2Rm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 3 5 4 rm1 5 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputStringInvalidQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("a a a a Q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputEmpty() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testRelInputBlank() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction(" \n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test
  public void testInputNonsense() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("zxr\n"),
        new PrintInteraction(this.exampleModelRelaxed.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelRelaxed, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1InvalidRow() {
    this.init();
    String test = "rm1 20 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1InvalidCard() {
    this.init();
    String test = "rm1 1 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1InvalidRowAndCard() {
    this.init();
    String test = "rm1 20 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1NegRow() {
    this.init();
    String test = "rm1 -2 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testInputStringRm1NegCard() {
    this.init();
    String test = "rm1 2 -1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testInputStringRm2RelaxedFailed() {
    this.init();
    //tries to make relaxed move, cannot because card is covered by two cards
    String test = "rmwd 0 6 1 rm2 6 1 5 0";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testInputStringRm2RelaxedFailed2() {
    this.init();
    //tries to make relaxed move, cannot because both cards are covered by two cards
    String test = "rm2 4 1 5 0";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRmwdNegRowAndCardAndInvalid() {
    this.init();
    String test = "rmwd -7 -3 a -8";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1NegRowAndCardAndInvalid() {
    this.init();
    String test = "rmw2 -7 -3 a -8 2";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testInputStringRmw2Invalid() {
    this.init();
    String test = "rmw2 4 6 4 3 q";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 3);
  }


  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1InvalidDeck() {
    this.init();
    String test = "rm1 2 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.invalidNonEmpty,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputString21() {
    this.init();
    String test = "rm2 1 1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.emptyDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1TooHighNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 10, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1NegDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, -1);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1TooLowNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 1, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1ZeroRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, 0, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringRm1NegRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testInputStringEmptyString() {
    this.init();
    String test = "";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringInvalidString() {
    this.init();
    String test = "s";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringOnlyNums() {
    this.init();
    String test = "1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelInputStringZeroDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, true, 5, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testRelAppendable() {
    this.init();
    String test = "6 7 5 4 q";
    StringReader in = new StringReader(test);
    Appendable out = new AppendableImpl();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelRelaxed, this.validDeck, false, 5, 50);
  }

  @Test
  public void testTriInputStringQuit1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("q 2 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringQuit() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("Q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputStringQuit2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 q 2 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 3, 3);

  }

  @Test
  public void testTriInputStringQuit3() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 q 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringQuit4() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("2 2 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }


  @Test
  public void testTriInputString1q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputStringRowQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 q 3 \n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputStringCardQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputString2q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringInvalid() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 2 t\n"),
        new PrintInteraction("Invalid move. Play again.\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputString3q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 3, 4);
  }


  @Test
  public void testTriInputString4q() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRm2() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 2 5 4\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRmwd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd 1 3 3\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 3, 4);
  }


  @Test
  public void testTriInputStringDd() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("dd 2\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringrm1Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm1 5 3\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);

  }

  @Test
  public void testTriInputStringRm2Invalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rm2 5 2 5 4\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRmwdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y rmwd 1 3 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 3, 4);
  }


  @Test
  public void testTriInputStringDdInvalid1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("y dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }


  @Test
  public void testTriInputStringRm1InvalidRowq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 ? 5 / 3 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRm2InvalidCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 r 2 5 4\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRmwdInvalidDrawCard() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rmwd k 1 i 3 3\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 3, 4);
  }

  @Test
  public void testTriInputStringRm1InvalidDdq() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 3 i dd 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriGameOver() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriGameOverBogus() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm1 5 2 rm2 5 1 5 3 dd 9 rm1 4 2 dd -9 rm1 29 rmwd 1 3 3\n"),
        new PrintInteraction("Game Over. Score: 20")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriGameOverWin() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 1 5 3 rm1 5 2 rmwd 3 4 2 dd 8 rm1 4 1 4 3\n"),
        new PrintInteraction("You win!")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringRm2Rm1() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("rm2 5 3 5 4 rm1 5 2 q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputStringInvalidQ() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("a a a a Q\n"),
        new PrintInteraction("Game quit!\nState of game when quit:\n"
                    + this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputEmpty() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputBlank() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction(" \n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test
  public void testTriInputNonsense() {
    this.init();
    Interaction[] interactions = new Interaction[] {
        new InputInteraction("zxr\n"),
        new PrintInteraction(this.exampleModelTri.toString() + "\nScore: 21\n")
    };
    this.testInteractions(this.exampleModelTri, interactions, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1InvalidRow() {
    this.init();
    String test = "rm1 20 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1InvalidCard() {
    this.init();
    String test = "rm1 1 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1InvalidRowAndCard() {
    this.init();
    String test = "rm1 20 20";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1NegRow() {
    this.init();
    String test = "rm1 -2 3";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1NegCard() {
    this.init();
    String test = "rm1 2 -1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.validDeck2, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRmwdNegRowAndCardAndInvalid() {
    this.init();
    String test = "rmwd -7 -3 a -8";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.validDeck2, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1NegRowAndCardAndInvalid() {
    this.init();
    String test = "rmw2 -7 -3 a -8 2";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.validDeck2, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRmw2Invalid() {
    this.init();
    String test = "rmw2 4 6 4 3 q";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.validDeck2, false, 5, 3);
  }


  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1InvalidDeck() {
    this.init();
    String test = "rm1 2 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.invalidNonEmpty,
            false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputString21() {
    this.init();
    String test = "rm2 1 1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.emptyDeck, false, 5, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1TooHighNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 10, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1NegDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 5, -1);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1TooLowNumRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            false, 1, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1ZeroRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            true, 0, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringRm1NegRows() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringEmptyString() {
    this.init();
    String test = "";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri,
            this.validDeck2, true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringInvalidString() {
    this.init();
    String test = "s";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2,
            true, -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringOnlyNums() {
    this.init();
    String test = "1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2, true,
            -3, 7);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriInputStringZeroDraw() {
    this.init();
    String test = "rm1 1 1";
    StringReader in = new StringReader(test);
    StringBuilder out = new StringBuilder();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2, true,
            5, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testTriAppendable() {
    this.init();
    String test = "6 7 5 4 q";
    StringReader in = new StringReader(test);
    Appendable out = new AppendableImpl();
    PyramidSolitaireController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(this.exampleModelTri, this.validDeck2, false,
            5, 50);
  }


  /**
   * a class that implements Appendable in order tp test the IOException when something is not
   * Appendable.
   */
  private class AppendableImpl implements Appendable {
    AppendableImpl() {
      // this constructor is empty because this class has been made for the sole purpose of
      // testing for Exceptions
    }

    @Override
    public Appendable append(CharSequence csq) throws IOException {
      throw new IOException();
    }

    @Override
    public Appendable append(CharSequence csq, int start, int end) throws IOException {
      throw new IOException();
    }

    @Override
    public Appendable append(char c) throws IOException {
      throw new IOException();
    }
  }
}