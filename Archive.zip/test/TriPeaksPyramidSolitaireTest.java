import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Class to test TriPeaksPyramidSolitaire methods.
 *
 */
public class TriPeaksPyramidSolitaireTest {

  Card c1;
  Card c2;
  Card c3;
  Card c4;
  Card c5;
  Card c6;
  Card c7;
  Card c8;

  List<Card> cardDrawList;
  List<Card> emptyList;
  List<Card> cardList1;
  List<Card> validDeck;
  List<Card> validDeck2;

  TriPeaksPyramidSolitaire game2;
  TriPeaksPyramidSolitaire game3;
  TriPeaksPyramidSolitaire game4;
  TriPeaksPyramidSolitaire game5;
  TriPeaksPyramidSolitaire gameEmpty;
  TriPeaksPyramidSolitaire overGame = new TriPeaksPyramidSolitaire();

  void init() {
    c1 = new Card(4, Card.Suit.Clubs, 2);
    c2 = new Card(13, Card.Suit.Spades, 2);
    c3 = new Card(9, Card.Suit.Diamonds, 2);
    c4 = new Card(11, Card.Suit.Hearts, 2);
    c5 = new Card(11, Card.Suit.Diamonds, 2);
    c6 = new Card(6, Card.Suit.Hearts, 2);
    c7 = new Card(6, Card.Suit.Hearts, 2);
    c8 = new Card(2, Card.Suit.Clubs, 2);

    cardDrawList = new ArrayList<Card>(Arrays.asList(c7, c8));
    emptyList = new ArrayList<Card>();
    cardList1 = new ArrayList<Card>(Arrays.asList(c1, c2, c3, c4, c5, c6, c7));

    game2 = new TriPeaksPyramidSolitaire();
    game3 = new TriPeaksPyramidSolitaire();
    game4 = new TriPeaksPyramidSolitaire();
    game5 = new TriPeaksPyramidSolitaire();
    gameEmpty = new TriPeaksPyramidSolitaire();
    overGame = new TriPeaksPyramidSolitaire();

    validDeck = this.game2.getDeck();
    validDeck2 = this.game3.getDeck();

    overGame.startGame(this.validDeck, false, 4, 3);

    game2.startGame(this.validDeck, false, 4, 3);
    game3.startGame(this.validDeck2, true, 4, 3);
    game4.startGame(this.validDeck, false, 2, 0);
    game5.startGame(this.validDeck, false, 3, 4);

  }


  @Test
  public void testNulls() {
    this.init();
    this.game5.startGame(this.validDeck, false, 5, 3);
    //first row should have null values in it from the start
    assertEquals(null, this.game5.getCardAt(0, 2));

  }

  @Test
  public void testRowLength() {
    this.init();
    this.game5.startGame(this.validDeck, false, 5, 3);
    //last row should not have the same width as the number of rows
    assertNotEquals(5, this.game5.getRowWidth(5));

  }


  @Test
  public void testStartGame() {
    this.init();
    Card card1 = new Card(11, Card.Suit.Spades, 2);
    Card card2 = new Card(12, Card.Suit.Spades, 2);
    Card card3 = new Card(13, Card.Suit.Spades, 2);
    ArrayList<Card> draw = new ArrayList<Card>(Arrays.asList(card1, card2, card3));

    assertEquals(55, this.game2.getScore());
    assertEquals(3, this.game2.getNumDraw());
    assertEquals(new Card(6, Card.Suit.Spades, 2), this.game2.getCardAt(2, 2));
    assertEquals(this.validDeck, this.game2.getDeck());
    assertEquals(104, this.game2.getDeck().size());
    assertEquals(draw, this.game2.getDrawCards());
    assertEquals(false,
            this.game3.getCardAt(0, 0).equals(new Card(1, Card.Suit.Clubs, 2)));
    assertEquals(false,
            this.game3.getCardAt(0, 0).equals(new Card(9, Card.Suit.Spades, 2)));
    assertEquals(4, this.game2.getNumRows());

  }

  @Test
  public void testStartGame2() {
    this.init();
    List<Card> unShuffle = this.game2.getDeck();
    List<Card> shuffle = this.game2.getDeck();
    this.game2.startGame(unShuffle, false, 3, 4);
    this.game2.startGame(shuffle, true, 3, 4);
    //size should stay the same after shuffling
    //if the shuffled deck was invalid, startGame will throw an IllegalArgumentException
    assertEquals(shuffle.size(), unShuffle.size());

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameE() {
    this.init();
    gameEmpty.startGame(cardList1, false,3, 5);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameE2() {
    this.init();
    gameEmpty.startGame(new ArrayList<Card>(), false,3, 5);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameE3() {
    this.init();
    gameEmpty.startGame(this.validDeck, false,3, 0);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameE4() {
    this.init();
    gameEmpty.startGame(this.validDeck, false,0, 2);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameE5() {
    this.init();
    gameEmpty.startGame(this.validDeck, false,1, 2);

  }

  @Test
  public void testRemoveUsingDraw() {
    this.init();
    //once removed, calling getCardAt should throw exception because it will be null
    this.game5.removeUsingDraw(0, 2, 2);
    assertEquals(null, game5.getCardAt(2, 2));

  }

  @Test
  public void testRemove2() {
    this.init();
    this.game5.startGame(this.validDeck, false, 5, 3);
    //once removed, calling getCardAt should throw exception because it will be null
    this.game5.remove(4, 1, 4, 3);
    assertEquals(null, this.game5.getCardAt(4, 1));

  }

  @Test
  public void testRemove3() {
    this.init();
    this.game5.startGame(this.validDeck, false, 5, 3);
    //once removed, calling getCardAt should throw exception because it will be null
    this.game5.remove(4, 1, 4, 3);
    assertEquals(null, this.game5.getCardAt(4, 3));
    //once removed, calling getCardAt should throw exception because it will be null
    this.game5.remove(4, 2);
    assertEquals(null, this.game5.getCardAt(4, 2));


  }



  //cards covered
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveE() {
    this.init();
    game2.remove(0,0,0,1);

  }

  //card covered
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveE2() {
    this.init();
    game2.remove(0,0);

  }

  //card uncovered but does not sum to 13
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveE3() {
    this.init();
    game2.remove(3,0);

  }

  //cards uncovered but do not sum to 13
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveE4() {
    this.init();
    game2.remove(3,0,3, 2);

  }

  //card uncovered but do not sum to 13
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveUsingDrawE() {
    this.init();
    game2.removeUsingDraw(0, 3,0);

  }

  //card uncovered but do not sum to 13, draw index invalid
  @Test(expected = IllegalArgumentException.class)
  public void testRemoveUsingDrawE2() {
    this.init();
    game2.removeUsingDraw(8, 3,0);

  }

  @Test
  public void testDiscardDraw() {
    this.init();
    Card cardDraw = new Card(1, Card.Suit.Clubs, 2);
    assertEquals(c7, this.cardDrawList.get(0));
    this.game2.discardDraw(0);
    assertEquals(cardDraw, this.game2.getDrawCards().get(0));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiscardDrawE() {
    this.init();
    this.game2.discardDraw(19);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiscardDrawE2() {
    this.init();
    this.game2.discardDraw(-1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiscardDrawE3() {
    this.init();
    this.game3.discardDraw(0);
    this.game2.discardDraw(-1);

  }

  @Test(expected = IllegalStateException.class)
  public void testDiscardDrawE4() {
    this.init();
    this.gameEmpty.discardDraw(0);

  }

  @Test
  public void testGetNumRows() {
    this.init();
    assertEquals(4, this.game2.getNumRows());
    assertEquals(2, this.game4.getNumRows());
    assertEquals(-1, this.gameEmpty.getNumRows());


  }

  @Test
  public void testGetNumDraw() {
    this.init();
    assertEquals(-1, this.gameEmpty.getNumDraw());
    assertEquals(3, this.game2.getNumDraw());
    assertEquals(0, this.game4.getNumDraw());


  }

  @Test
  public void testGetRowWidth() {
    this.init();
    assertEquals(2, this.game2.getRowWidth(1));
    assertEquals(3, this.game2.getRowWidth(2));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetRowWidthE() {
    this.init();
    this.game2.getRowWidth(-1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetRowWidthE2() {
    this.init();
    this.game2.getRowWidth(20);

  }

  @Test(expected = IllegalStateException.class)
  public void testGetRowWidthE3() {
    this.init();
    this.gameEmpty.getRowWidth(2);

  }

  @Test
  public void testIsGameOver() {
    this.init();
    assertEquals(false, this.game2.isGameOver());
    //game is won
    assertEquals(true, this.game3.isGameOver());
    //no more moves can be made
    assertEquals(true, this.game5.isGameOver());

  }

  @Test(expected = IllegalStateException.class)
  public void testIsGameOverE() {
    this.init();
    this.gameEmpty.isGameOver();

  }

  @Test
  public void testGetScore() {
    this.init();
    assertEquals(55, this.game2.getScore());

  }

  @Test(expected = IllegalStateException.class)
  public void testGetScoreE() {
    this.init();
    this.gameEmpty.getScore();

  }

  @Test
  public void testGetCardAt() {
    this.init();
    Card c = new Card(2, Card.Suit.Spades, 2);
    Card c2 = new Card(6, Card.Suit.Spades, 2);
    assertEquals(c, this.game2.getCardAt(1,0));
    assertEquals(c2, this.game2.getCardAt(2,2));
    assertEquals(false,
            this.game2.getCardAt(2,2).equals(new Card(6, Card.Suit.Diamonds,
                    2)));
    assertEquals(false,
            this.game2.getCardAt(2,2).equals(new Card(7, Card.Suit.Spades,
                    2)));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAtE() {
    this.init();
    this.game2.getCardAt(-1, 2);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAtE2() {
    this.init();
    this.game2.getCardAt(2, -1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAtE3() {
    this.init();
    this.game2.getCardAt(20, 2);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAtE4() {
    this.init();
    this.game2.getCardAt(2, 20);

  }

  @Test(expected = IllegalStateException.class)
  public void testGetCardAtE5() {
    this.init();
    this.gameEmpty.getCardAt(2, 2);

  }

  @Test
  public void testGetDrawCards() {
    this.init();
    Card cDraw1 = new Card(11, Card.Suit.Spades, 2);
    Card cDraw2 = new Card(12, Card.Suit.Spades, 2);
    Card cDraw3 = new Card(13, Card.Suit.Spades, 2);
    assertEquals(new ArrayList<Card>(Arrays.asList(cDraw1, cDraw2, cDraw3)),
            this.game2.getDrawCards());

  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetDrawCardsE() {
    this.init();
    this.game2.getDrawCards();

  }

  @Test
  public void testToString4Rows() {
    this.init();
    String drawGame = "      A♠     2♠    3♠\n    4♠   5♠   6♠   7♠   8♠   9♠" +
            "\n  10♠  J♠  Q♠  K♠  A♣  2♣  3♣  4♣  5♣\n6♣  7♣  8♣  9♣  10♣ J♣  Q♣  K♣  A♥" +
            "\nDraw: 2♥, 3♥, 4♥";
    assertEquals(drawGame, this.game2.toString());

  }

  @Test
  public void testToStringEmpty() {
    this.init();
    String drawGame = "";
    assertEquals(drawGame, this.gameEmpty.toString());
  }

  @Test
  public void testToStringGameOverWin() {
    this.init();
    String drawGame = "Game over. Score: 0";
    assertEquals(drawGame, this.game5.toString());
  }

  @Test
  public void testToStringGameOverLoss() {
    this.init();
    String drawGame = "Game over. Score: 10";
    assertEquals(drawGame, this.game5.toString());
  }

  @Test
  public void testToString5() {
    this.init();
    this.game5.startGame(this.validDeck, false, 5, 3);
    this.game5.remove(4, 1, 4, 3);
    String drawGame = "        A♠\n      2♠  3♠\n    4♠  5♠  6♠\n  7♠  8♠  9♠  10♠" +
            "\nJ♠      K♠      2♣\nDraw: 3♣, 4♣, 5♣";
    assertEquals(drawGame, this.game5.toString());

  }

  @Test
  public void testToString2Rows() {
    this.init();
    this.game5.startGame(this.validDeck, false, 2, 3);
    String drawGame = "  A♠  2♠  3♠\n4♠  5♠  6♠  7♠\nDraw: 8♠, 9♠, 10♠";
    assertEquals(drawGame, this.game5.toString());

  }


}