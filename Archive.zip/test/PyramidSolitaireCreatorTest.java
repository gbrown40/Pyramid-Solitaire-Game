import org.junit.Test;

import static org.junit.Assert.assertEquals;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;


/**
 * A class used for testing PyramidSolitaireCreator.
 */
public class PyramidSolitaireCreatorTest {
  BasicPyramidSolitaire basic = new BasicPyramidSolitaire();
  RelaxedPyramidSolitaire relaxed = new RelaxedPyramidSolitaire();
  TriPeaksPyramidSolitaire tripeaks = new TriPeaksPyramidSolitaire();


  @Test
  public void testTypes() {
    PyramidSolitaireCreator creator = new PyramidSolitaireCreator();
    assertEquals(basic, creator.create(PyramidSolitaireCreator.GameType.BASIC));
    assertEquals(relaxed, creator.create(PyramidSolitaireCreator.GameType.RELAXED));
    assertEquals(tripeaks, creator.create(PyramidSolitaireCreator.GameType.TRIPEAKS));

  }

  @Test(expected = IllegalStateException.class)
  public void testNull() {
    PyramidSolitaireCreator creator = new PyramidSolitaireCreator();
    creator.create(null);

  }

}
