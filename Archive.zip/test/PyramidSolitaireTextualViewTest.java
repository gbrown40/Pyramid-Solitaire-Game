import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

/**
 * A class used for testing the playGame() method in the MarbleSolitaireControllerImplTest class.
 */

public class PyramidSolitaireTextualViewTest {

  BasicPyramidSolitaire gameBasic;
  BasicPyramidSolitaire gameBasic2;
  BasicPyramidSolitaire gameBasic3;
  RelaxedPyramidSolitaire gameRel;
  RelaxedPyramidSolitaire gameTri;
  RelaxedPyramidSolitaire gameEmpty;

  PyramidSolitaireTextualView view;
  PyramidSolitaireTextualView view2;
  PyramidSolitaireTextualView view3;


  List<Card> validDeck;
  List<Card> validDeck2;

  Appendable ap;
  Appendable ap2;


  void init() {

    ap = new StringBuilder();
    ap2 = new StringBuilder("j");

    gameBasic = new BasicPyramidSolitaire();
    gameBasic2 = new BasicPyramidSolitaire();
    gameBasic3 = new BasicPyramidSolitaire();
    gameRel = new RelaxedPyramidSolitaire();
    gameTri = new RelaxedPyramidSolitaire();
    gameEmpty = new RelaxedPyramidSolitaire();

    validDeck = this.gameBasic2.getDeck();
    validDeck2 = this.gameRel.getDeck();

    gameBasic.startGame(this.validDeck, false, 4, 3);
    gameBasic2.startGame(this.validDeck, false, 5, 3);
    gameBasic3.startGame(this.validDeck, false, 9, 3);
    gameRel.startGame(this.validDeck, false, 9, 3);
    gameTri.startGame(this.validDeck2, false, 9, 3);

    view = new PyramidSolitaireTextualView(gameBasic);
    view2 = new PyramidSolitaireTextualView(gameBasic2);
    view3 = new PyramidSolitaireTextualView(gameBasic3);

  }


  @Test
  public void testToString() {
    this.init();
    String drawGame = "      A♠\n    2♠  3♠\n  4♠  5♠  6♠\n7♠  8♠  9♠  10♠\nDraw: J♠, Q♠, K♠";
    assertEquals(drawGame, this.view.toString());

  }

  @Test
  public void testToString2() {
    this.init();
    String drawGame = "";
    assertEquals(drawGame, this.view.toString());
  }

  @Test
  public void testToString3() {
    this.init();
    String drawGame = "Game over. Score: 0";
    assertEquals(drawGame, this.view.toString());
  }

  @Test
  public void testToString4() {
    this.init();
    String drawGame = "Game over. Score: 10";
    assertEquals(drawGame, this.view.toString());
  }

  @Test
  public void testToString5() {
    this.init();
    this.gameBasic2.remove(4, 1, 4, 3);
    String drawGame = "        A♠\n      2♠  3♠\n    4♠  5♠  6♠\n  7♠  8♠  9♠  10♠" +
            "\nJ♠      K♠      2♣\nDraw: 3♣, 4♣, 5♣";
    assertEquals(drawGame, this.view2.toString());

  }

  @Test
  public void testToString6() {
    this.init();
    String drawGame = "                A♠\n              2♠  3♠" +
            "\n            4♠  5♠  6♠\n          7♠  8♠  9♠  10♠" +
            "\n        J♠  Q♠  K♠  A♣  2♣\n      3♣  4♣  5♣  6♣  7♣  8♣" +
            "\n    9♣  10♣ J♣  Q♣  K♣  A♥  2♥\n  3♥  4♥  5♥  6♥  7♥  8♥  9♥  10♥" +
            "\nJ♥  Q♥  K♥  A♦  2♦  3♦  4♦  5♦  6♦\nDraw: 7♦, 8♦, 9♦";
    assertEquals(drawGame, this.view3.toString());

  }

  @Test
  public void testRender() throws IOException {
    this.init();
    String drawGame = "      A♠\n    2♠  3♠\n  4♠  5♠  6♠\n7♠  8♠  9♠  10♠\nDraw: J♠, Q♠, K♠";
    this.view.render();
    assertEquals(drawGame, this.ap);

  }

  @Test
  public void testRender2() throws IOException {
    this.init();
    String drawGame = "";
    this.view.render();
    assertEquals(drawGame, this.ap);
  }

  @Test
  public void testRender3() throws IOException {
    this.init();
    String drawGame = "Game over. Score: 0";
    this.view.render();
    assertEquals(drawGame, this.ap);
  }

  @Test
  public void testRender4() throws IOException {
    this.init();
    String drawGame = "Game over. Score: 10";
    this.view.render();
    assertEquals(drawGame, this.ap);
  }

  @Test
  public void testRender5() throws IOException {
    this.init();
    this.gameBasic2.remove(4, 1, 4, 3);
    String drawGame = "        A♠\n      2♠  3♠\n    4♠  5♠  6♠\n  7♠  8♠  9♠  10♠" +
            "\nJ♠      K♠      2♣\nDraw: 3♣, 4♣, 5♣";
    this.view.render();
    assertEquals(drawGame, this.ap);

  }

  @Test
  public void testRender6() throws IOException {
    this.init();
    String drawGame = "                A♠\n              2♠  3♠" +
            "\n            4♠  5♠  6♠\n          7♠  8♠  9♠  10♠" +
            "\n        J♠  Q♠  K♠  A♣  2♣\n      3♣  4♣  5♣  6♣  7♣  8♣" +
            "\n    9♣  10♣ J♣  Q♣  K♣  A♥  2♥\n  3♥  4♥  5♥  6♥  7♥  8♥  9♥  10♥" +
            "\nJ♥  Q♥  K♥  A♦  2♦  3♦  4♦  5♦  6♦\nDraw: 7♦, 8♦, 9♦";
    this.view.render();
    assertEquals(drawGame, this.ap);

  }

  @Test
  public void testRender7() throws IOException {
    this.init();
    String drawGame = "                A♠\n              2♠  3♠" +
            "\n            4♠  5♠  6♠\n          7♠  8♠  9♠  10♠" +
            "\n        J♠  Q♠  K♠  A♣  2♣\n      3♣  4♣  5♣  6♣  7♣  8♣" +
            "\n    9♣  10♣ J♣  Q♣  K♣  A♥  2♥\n  3♥  4♥  5♥  6♥  7♥  8♥  9♥  10♥" +
            "\nJ♥  Q♥  K♥  A♦  2♦  3♦  4♦  5♦  6♦\nDraw: 7♦, 8♦, 9♦";
    this.view.render();
    assertEquals("j" + drawGame, this.ap);

  }

  @Test
  public void testToString4Rows() {
    this.init();
    String drawGame = "      A♠     2♠    3♠\n    4♠   5♠   6♠   7♠   8♠   9♠" +
            "\n  10♠  J♠  Q♠  K♠  A♣  2♣  3♣  4♣  5♣\n6♣  7♣  8♣  9♣  10♣ J♣  Q♣  K♣  A♥" +
            "\nDraw: 2♥, 3♥, 4♥";
    assertEquals(drawGame, this.gameTri.toString());

  }

  @Test
  public void testToStringEmpty() {
    this.init();
    String drawGame = "";
    assertEquals(drawGame, this.gameEmpty.toString());
  }

  @Test
  public void testToStringGameOverWin() {
    this.init();
    String drawGame = "Game over. Score: 0";
    assertEquals(drawGame, this.gameTri.toString());
  }

  @Test
  public void testToStringGameOverLoss() {
    this.init();
    String drawGame = "Game over. Score: 10";
    assertEquals(drawGame, this.gameTri.toString());
  }

  @Test
  public void testToStringTri5Rows() {
    this.init();
    this.gameTri.startGame(this.validDeck, false, 5, 3);
    this.gameTri.remove(4, 1, 4, 3);
    String drawGame = "        A♠\n      2♠  3♠\n    4♠  5♠  6♠\n  7♠  8♠  9♠  10♠" +
            "\nJ♠      K♠      2♣\nDraw: 3♣, 4♣, 5♣";
    assertEquals(drawGame, this.gameTri.toString());

  }

  @Test
  public void testToString2Rows() {
    this.init();
    this.gameTri.startGame(this.validDeck, false, 2, 3);
    String drawGame = "  A♠  2♠  3♠\n4♠  5♠  6♠  7♠\nDraw: 8♠, 9♠, 10♠";
    assertEquals(drawGame, this.gameTri.toString());

  }

  @Test
  public void testToStringRel4Rows() {
    this.init();
    String drawGame = "      A♠\n    2♠  3♠\n  4♠  5♠  6♠\n7♠  8♠  9♠  10♠\nDraw: J♠, Q♠, K♠";
    assertEquals(drawGame, this.gameRel.toString());

  }

  @Test
  public void testToString3RelGameOverWin() {
    this.init();
    String drawGame = "Game over. Score: 0";
    assertEquals(drawGame, this.gameRel.toString());
  }

  @Test
  public void testToString4RelGameOverLoss() {
    this.init();
    String drawGame = "Game over. Score: 10";
    assertEquals(drawGame, this.gameRel.toString());
  }

  @Test
  public void testToString5Rel5Rows() {
    this.init();
    this.gameRel.startGame(this.validDeck, false, 5, 3);
    this.gameRel.remove(4, 1, 4, 3);
    String drawGame = "        A♠\n      2♠  3♠\n    4♠  5♠  6♠\n  7♠  8♠  9♠  10♠" +
            "\nJ♠      K♠      2♣\nDraw: 3♣, 4♣, 5♣";
    assertEquals(drawGame, this.gameRel.toString());

  }

  @Test
  public void testToString6Rel4Suits() {
    this.init();
    this.gameRel.startGame(this.validDeck, false, 9, 3);
    String drawGame = "                A♠\n              2♠  3♠" +
            "\n            4♠  5♠  6♠\n          7♠  8♠  9♠  10♠" +
            "\n        J♠  Q♠  K♠  A♣  2♣\n      3♣  4♣  5♣  6♣  7♣  8♣" +
            "\n    9♣  10♣ J♣  Q♣  K♣  A♥  2♥\n  3♥  4♥  5♥  6♥  7♥  8♥  9♥  10♥" +
            "\nJ♥  Q♥  K♥  A♦  2♦  3♦  4♦  5♦  6♦\nDraw: 7♦, 8♦, 9♦";
    assertEquals(drawGame, this.gameRel.toString());

  }
}
