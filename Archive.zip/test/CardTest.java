import cs3500.pyramidsolitaire.model.hw02.Card;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Class to Test Card methods.
 */
public class CardTest {

  Card c1 = new Card(4, Card.Suit.Clubs, 2);
  Card c2 = new Card(13, Card.Suit.Spades, 2);
  Card c3 = new Card(9, Card.Suit.Diamonds, 2);
  Card c4 = new Card(11, Card.Suit.Hearts, 2);

  ArrayList<Card> emptyList = new ArrayList<Card>();
  ArrayList<Card> cardList1 = new ArrayList<Card>(Arrays.asList(c1, c2, c3, c4));


  @Test
  public void testEquals() {
    assertEquals(false, c1.equals(c2));
    assertEquals(true, c1.equals(c1));
  }

  @Test
  public void testToString() {
    assertEquals("4♣", c1.toString());
    assertEquals("K♠", c2.toString());
    assertEquals("9♦", c3.toString());
    assertEquals("J♥", c4.toString());
  }

}
