Changes made from hw 2 code:

startGame now throws an exception if the numRows and or numDraws is not valid for a 52 card game.
I also added tests for this

the way I add cards to the uncovered list in removeHelper is different. I changed it so that
there would be no index out of bound errors

toString() now displays "You win!" if the game is over and the score is 0

startGame now throws an exception if the deck is empty

isGameOver now checks if any draw cards can be discarded

I added tests for the view